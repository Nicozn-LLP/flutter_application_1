import 'package:flutter/material.dart';

class TopNavigationBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 56, // Adjust the height as needed
      color: Colors.black, // Set your preferred background color
      
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Image.asset(
              'assets/logo.png', // Replace 'assets/logo.png' with your logo image path
              height: 40, // Adjust the height as needed
            ),
          ),
          
          Row(
            children: [
              IconButton(
                icon: Icon(Icons.location_on),
                color: Colors.white,
                onPressed: () {
                  // Add your location icon functionality here
                },
              ),
              IconButton(
                icon: Icon(Icons.search),
                color: Colors.white,
                onPressed: () {
                  // Add your search icon functionality here
                },
              ),
            ],
          ),
        ],
      ),
    );
  }
}
