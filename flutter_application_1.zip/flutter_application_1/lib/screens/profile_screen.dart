import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 500,
      height: 700,
      color: const Color(0xFFFFFFFF),
      child: Stack(
        children: [
          Positioned(
            width: 318.26,
            height: 90,
            left: 198 - 318.26 / 2 + 0.13,
            top: 50,
            child: Container(
              decoration: BoxDecoration(
                color: Colors.black,
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          ),
          Positioned(
            width: 60,
            height: 60,
            left: 125 - 120 / 2,
            top: 66,
            child: Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.grey,
                image: DecorationImage(
                  image: AssetImage('assets/images/photo.jpg'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          Positioned(
            width: 200,
            height: 18,
            left: 200 - 102 / 2,
            top: 85,
            child: Text(
              'James Dsouza',
              style: TextStyle(
                fontFamily: 'Inter',
                fontWeight: FontWeight.w500,
                fontSize: 17,
                color: Colors.white,
              ),
            ),
          ),
          Positioned(
            width: 24,
            height: 24,
            left: 300,
            top: 82,
            child: Icon(
              Icons.arrow_right,
              color: Colors.white,
            ),
          ),
          Positioned(
            width: 318.26,
            height: 50,
            left: 198 - 318.26 / 2 + 0.13,
            top: 180,
            child: Container(
              decoration: BoxDecoration(
                color: Colors.black,
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          ),
          Positioned(
            width: 100,
            height: 22,
            left: 85 - 43 / 2 + 1.5,
            top: 196,
            child: Text(
              'Account',
              style: TextStyle(
                fontFamily: 'Inter',
                fontWeight: FontWeight.w500,
                fontSize: 15,
                color: const Color(0xFFFFFFFF),
              ),
            ),
          ),
          Positioned(
            width: 24,
            height: 24,
            left: 300,
            top: 194,
            child: Icon(
              Icons.arrow_right,
              color: Colors.white,
            ),
          ),
          Positioned(
            width: 318.26,
            height: 50,
            left: 198 - 318.26 / 2 + 0.13,
            top: 260,
            child: Container(
              decoration: BoxDecoration(
                color: Colors.black,
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          ),
          Positioned(
            width: 100,
            height: 22,
            left: 85 - 43 / 2 + 1.5,
            top: 275,
            child: Text(
              'About',
              style: TextStyle(
                fontFamily: 'Inter',
                fontWeight: FontWeight.w500,
                fontSize: 15,
                color: const Color(0xFFFFFFFF),
              ),
            ),
          ),
          Positioned(
            width: 24,
            height: 24,
            left: 300,
            top: 272,
            child: Icon(
              Icons.arrow_right,
              color: Colors.white,
            ),
          ),
          Positioned(
            width: 318.26,
            height: 50,
            left: 198 - 318.26 / 2 + 0.13,
            top: 340,
            child: Container(
              decoration: BoxDecoration(
                color: Colors.black,
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          ),
          Positioned(
            width: 200,
            height: 22,
            left: 85 - 43 / 2 + 1.5,
            top: 355,
            child: Text(
              'Terms of Service',
              style: TextStyle(
                fontFamily: 'Inter',
                fontWeight: FontWeight.w500,
                fontSize: 15,
                color: const Color(0xFFFFFFFF),
              ),
            ),
          ),
          Positioned(
            width: 24,
            height: 24,
            left: 300,
            top: 353,
            child: Icon(
              Icons.arrow_right,
              color: Colors.white,
            ),
          ),
          Positioned(
            width: 318.26,
            height: 50,
            left: 198 - 318.26 / 2 + 0.13,
            top: 420,
            child: Container(
              decoration: BoxDecoration(
                color: Colors.black,
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          ),
          Positioned(
            width: 200,
            height: 22,
            left: 85 - 43 / 2 + 1.5,
            top: 435,
            child: Text(
              'Privacy Policy',
              style: TextStyle(
                fontFamily: 'Inter',
                fontWeight: FontWeight.w500,
                fontSize: 15,
                color: const Color(0xFFFFFFFF),
              ),
            ),
          ),
          Positioned(
            width: 24,
            height: 24,
            left: 300,
            top: 433,
            child: Icon(
              Icons.arrow_right,
              color: Colors.white,
            ),
          ),
          Positioned(
            width: 318.26,
            height: 50,
            left: 198 - 318.26 / 2 + 0.13,
            top: 540,
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xFF005851),
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          ),
          Positioned(
            width: 200,
            height: 22,
            left: 185 - 43 / 2 + 1.5,
            top: 555,
            child: Text(
              'Log-Out',
              style: TextStyle(
                fontFamily: 'Inter',
                fontWeight: FontWeight.w500,
                fontSize: 15,
                color: const Color(0xFFFFFFFF),
              ),
            ),
          ),
          Positioned(
            width: 24,
            height: 24,
            left: 300,
            top: 353,
            child: Icon(
              Icons.arrow_right,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}
